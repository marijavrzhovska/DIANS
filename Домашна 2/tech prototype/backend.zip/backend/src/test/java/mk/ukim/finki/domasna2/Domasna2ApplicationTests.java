package mk.ukim.finki.domasna2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Domasna2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
